 /* CPSC 2150 - Final Project
  * Joel Miller
  * Connect X
  * March 7, 2023
  */



package cpsc2150.extendedConnectX.models;

 /**
  * An interface representing a game board.
  * A game board is a grid-like data structure used in various board games.
  * It provides methods for querying the current state of the board, as well
  * as making and undoing moves on the board.
  *
  * Initialization ensures:
  * The game board is in a valid starting state according to the rules of the game.
  *
  * Defines:
  *
  * ROWS: the number of rows on the game board.
  *
  * COLUMNS: the number of columns on the game board.
  *
  * Constraints:
  * ROWS > 0, COLUMNS > 0
  */
public interface IGameBoard {

     char[][] board = new char[9][7];

     /**
      * Returns true if the column can accept another token; false otherwise.
      *
      * * @param c The column to check.
      * @return True if the column is free, false otherwise.
      * @post returns true if there is at least one row in column `c` that is empty; false otherwise.
      */
     public default boolean checkIfFree(int c){
         BoardPosition bp = new BoardPosition(getNumRows() - 1, c);
         if(whatsAtPos(bp) == ' ')
         {
             return true;
         }
         return false;
     }




     /**
      * This function will check to see if the last token placed in
      * column c resulted in the player winning the game. If so, it will return
      * true, otherwise false.
      * @pre  c is the column where the latest token was placed
      * @param c The column where the last token was placed.
      * @return True if the placed token is the last to make up the maximum number
      * of consecutive same markers needed to win either vertically, horizontally, or diagonally, false otherwise.
      * @Post returns true if the last token placed in column c results in a winning condition; false otherwise
      */
     public default boolean checkForWin(int c){
         BoardPosition bp = null;
         char person = '.';

         for (int j = 1; j < getNumRows(); j++)
         {
             bp = new BoardPosition(j, c);

             if (whatsAtPos(bp) == ' ')
             {
                 bp = new BoardPosition(j - 1, c);

                 person = whatsAtPos(bp);
                 break;
             }
         }
         if(checkHorizWin(bp, person))
         {
             return true;
         }
         if(checkVertWin(bp, person))
         {
             return true;
         }
         if(checkDiagWin(bp, person))
         {
             return true;
         }

         return false;
     }


     /**
      * This function will check to see if the game has resulted in a
      * tie. A game is tied if there are no free board positions remaining.
      * You do not need to check for any potential wins because we can assume
      * that the players were checking for win conditions as they played the
      * game. It will return true if the game is tied and false otherwise.
      *
      * @return True if the game is a tie, false otherwise.
      * @post returns true if there are no more empty positions in the game board; false otherwise.
      */
     public default boolean checkTie(){
         for(int i = 0; i < getNumColumns(); i++){
             if (checkIfFree(i)){
                 return false;
             }
         }
         return true;
     }

     /**
      * checks to see if the last token placed (which was placed in
      * position pos by player p) resulted in 5 in a row horizontally. Returns
      * true if it does, otherwise false.
      *
      * @param pos The BoardPosition of the last token placed.
      * @param p   The player's token
      * @return True if the player has won, false otherwise.
      * @post returns true if there are 5 consecutive tokens of player `p` horizontally in the row of `pos`; false otherwise.
      */
     public default boolean checkHorizWin(BoardPosition pos, char p){
         int num = 1;
         BoardPosition bp = null;
         for(int j = pos.getColumn() + 1; j < getNumColumns(); j++) {
             bp = new BoardPosition(pos.getRow(), j);
             if (whatsAtPos(pos) == whatsAtPos(bp)) {
                 num++;
             }
             else {break;}
         }
         for(int k = pos.getColumn() - 1; k >= 0; k--)
         {
             bp = new BoardPosition(pos.getRow(), k);

             if (whatsAtPos(pos) == whatsAtPos(bp))
             {
                 num++;
             }
             else {break;}
         }

         if(num >= getNumToWin())
         {
             return true;
         }
         else {return false;}
     }

     /**
      * Checks to see if the last token placed (which was placed in
      * position pos by player p) resulted in 5 in a row vertically. Returns
      * true if it does, otherwise false.
      *
      * @param pos The BoardPosition of the last token placed.
      * @param p   The player's token
      * @return True if the player has won, false otherwise.
      * @post returns true if there are 5 consecutive tokens of player `p` vertically in the column of `pos`; false otherwise.
      */
     public default boolean checkVertWin(BoardPosition pos, char p)
     {
         int num = 1;
         BoardPosition bp = null;

         for(int row = pos.getRow() + 1; row < getNumRows(); row++)
         {
             bp = new BoardPosition(row, pos.getColumn());
             if (isPlayerAtPos(bp, p))
             {
                 num++;
             }
             else {break;}
         }
         for(int row = pos.getRow() - 1; row >= 0; row--)
         {
             bp = new BoardPosition(row, pos.getColumn());
             if ( isPlayerAtPos(bp, p))
             {
                 num++;
             }
             else {break;}
         }

         if(num >= getNumToWin())
         {
             return true;
         }
         else
         {
             return false;
         }
     }

     /**
      * checks to see if the last token placed (which was placed in
      * position pos by player p) resulted in 5 in a row diagonally. Returns
      * true if it does, otherwise false
      *
      * @param pos The BoardPosition of the last token placed.
      * @param p   The player's token
      * @return True if the player has won, false otherwise.
      * @post returns true if there are 5 consecutive tokens of player `p` diagonally in the column of `pos`; false otherwise.
      */
     public default boolean checkDiagWin(BoardPosition pos, char p){
         int COL = pos.getColumn() + 1;


         int num = 1;

         int ROW = pos.getRow() + 1;


         BoardPosition bp = null;



         while(ROW < getNumRows() && COL < getNumColumns())
         {
             bp = new BoardPosition(ROW, COL);
             if (isPlayerAtPos(bp, p)){
                 num++;
                 ROW++;
                 COL++;
             }
             else {break;}
         }

         ROW = pos.getRow() - 1;
         COL = pos.getColumn() - 1;




         while(ROW >= 0 && COL >= 0){
             bp = new BoardPosition(ROW, COL);


             if (isPlayerAtPos(bp, p))
             {
                 num++;
                 ROW--;
                 COL--;
             }
             else {break;}
         }



         if(num >= getNumToWin())
         {
             return true;
         }
         else {num = 1;}

         ROW = pos.getRow() + 1;
         COL = pos.getColumn() - 1;





         while(ROW < getNumRows() && COL >= 0){
             bp = new BoardPosition(ROW, COL);
             if (isPlayerAtPos(bp, p)){
                 num++;
                 ROW++;
                 COL--;
             }
             else {break;}
         }
         ROW = pos.getRow() - 1;
         COL = pos.getColumn() + 1;



         while(ROW >= 0 && COL < getNumColumns())
         {
             bp = new BoardPosition(ROW, COL);
             if (isPlayerAtPos(bp, p)){
                 num++;
                 ROW--;
                 COL++;
             }
             else {break;}
         }


         if(num >= getNumToWin())
         {
             return true;
         }
         else {return false;}

     }
     /**
      * Returns true if the player is at pos; otherwise, it returns false
      *
      * @param pos The board position to check
      * @param player The player character to search for
      * @return `true` if the player is at the given position; `false` otherwise.
      *
      * @post `getPlayerAtPos(pos) == player` if the method returns `true`;
      *       `getPlayerAtPos(pos) != player` if the method returns `false`
      */
     public default boolean isPlayerAtPos(BoardPosition pos, char player){
         if(whatsAtPos(pos) == player)
         {
             return true;
         }
         return false;
     }
     /**
      * returns the number of rows in the GameBoard
      *
      * @return  The number of rows
      * @post getNumRows = r
      */
     public int getNumRows();
     /**
      * returns the number of columns in the GameBoard
      *
      * @return  The number of columns
      * @post getNumColumns = c
      */
     public int getNumColumns();

     /**
      * returns the number of tokens in a row needed to win the game
      *
      * @return  The number of tokens
      *
      */
     public int getNumToWin();
     /**
      * Returns the character that is in the GameBoard at the specified position.
      * If no marker is present at the position, a blank space character is returned.
      *
      * @param pos the BoardPosition to check for a marker
      * @return the character at the specified position, or a blank space character if no marker is present
      * @throws IndexOutOfBoundsException if the specified position is outside the bounds of the GameBoard
      */
     public char whatsAtPos(BoardPosition pos);
     /**
      * Places the character p in column c. The token will be placed in
      * the lowest available row in column c.
      *
      * @param p The player's token (e.g. 'X' or 'O').
      * @param c The column to place the token in.
      * @post a new token `p` has been placed in column `c` at the lowest available row.
      */
     public void placeToken(char p, int c);

}
