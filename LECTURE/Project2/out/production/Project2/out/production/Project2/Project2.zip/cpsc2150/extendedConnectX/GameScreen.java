 /* CPSC 2150 - Final Project
  * Joel Miller
  * Connect X
  * March 7, 2023
  */





 package cpsc2150.extendedConnectX;

import java.util.Scanner;
import cpsc2150.extendedConnectX.models.GameBoard;
import cpsc2150.extendedConnectX.models.IGameBoard;

public class GameScreen {

 public static void main(String[] args) {
  Scanner scanner = new Scanner(System.in);

  IGameBoard bo = new GameBoard();

  char person = 'X';
  int COL = -1;
  boolean loop = true;

  while (loop)
  {
   // Clear the board at the start of each game
   for (int i = 0; i < bo.getNumRows(); i++) {
    for (int j = 0; j < bo.getNumColumns(); j++) {
     bo.placeToken(' ', j);
    }
   }

   System.out.println(bo.toString());


   boolean VC = false;

   while (!VC) {
    System.out.println("Player " + person + ", what column do you want to place your marker in?");
    COL = scanner.nextInt();

    if (COL < 0)
    {
     System.out.println("Column cannot be less than 0");
    } else if (COL >= bo.getNumColumns()) {
     System.out.println("Column cannot be greater than 6");
    } else if (!bo.checkIfFree(COL)) {
     System.out.println("Column is full");
    } else {
     VC = true;
    }
   }

   bo.placeToken(person, COL);

   if (bo.checkForWin(COL)) {
    System.out.println(bo.toString());
    System.out.println("Player " + person + " Won!");
    System.out.println("Would you like to play again? Y/N");

    String input = scanner.next().toUpperCase();
    loop = input.equals("Y");
    if (loop) {
     person = 'X';
    }
   } else if (bo.checkTie()) {
    System.out.println(bo.toString());
    System.out.println("The game is a tie!");
    System.out.println("Would you like to play again? Y/N");

    String input = scanner.next().toUpperCase();
    loop = input.equals("Y");
    if (loop) {
     person = 'X';
    }
   } else {
    person = (person == 'X') ? 'O' : 'X';
   }
  }
 }
}
